<?php
/**
 * This file config of custom control for customizer.
 *
 * @package Cleanco
 */

if ( function_exists( 'detheme_display_footer_builder' ) ) {
	$cleanco_customizer_settings['footer-option'] = array(
		'section'     => 'footer-section',
		'type'        => 'select',
		'default'     => 'footer-widget',
		'label'       => esc_html__( 'Select Footer', 'cleanco' ),
		'transport'   => 'refresh',
		'description' => esc_html__( 'Select widget or page to appear on Footer.', 'cleanco' ),
		'choices'     => array(
			'footer-widget' => esc_html__( 'Footer from Widget', 'cleanco' ),
			'footer-page'   => esc_html__( 'Footer from Page', 'cleanco' ),
		),
	);

	$cleanco_customizer_settings['footer-url'] = array(
		'section'     => 'footer-section',
		'type'        => 'custom',
		'custom_type' => 'cleanco-link',
		'default'     => '',
		'label'       => esc_html__( 'Click here to edit footer widgets', 'cleanco' ),
		'description' => esc_html__( '#', 'cleanco' ),
		'transport'   => 'refresh',
	);

	$cleanco_customizer_settings['footer-content'] = array(
		'section'     => 'footer-section',
		'type'        => 'select',
		'default'     => 'cleanco-page-1',
		'label'       => esc_html__( 'Footer from Page', 'cleanco' ),
		'transport'   => 'refresh',
		'description' => esc_html__( 'Select a page to appear on Footer.', 'cleanco' ),
		'choices'     => detheme_get_pages_array(),
	);
}

$cleanco_customizer_settings['footer-display-copyright'] = array(
	'section'     => 'footer-section',
	'type'        => 'custom',
	'custom_type' => 'cleanco-switcher',
	'label'       => esc_html__( 'Copyright Text', 'cleanco' ),
	'description' => esc_html__( 'Write your copyright', 'cleanco' ),
	'default'     => true,
	'choices'     => array(
		false => esc_html__( 'Hidden', 'cleanco' ),
		true  => esc_html__( 'Show', 'cleanco' ),
	),
);

/* translators: %s: site legal */
$default = sprintf( esc_html__( 'Copyright %s', 'cleanco' ), get_bloginfo( 'name' ) );

$cleanco_customizer_settings['footer-legal'] = array(
	'section'     => 'footer-section',
	'type'        => 'textarea',
	'default'     => $default,
	'transport'   => 'postMessage',
	'input_attrs' => array(
		'class'       => 'my-custom-class',
		'placeholder' => esc_html__( 'Enter message...', 'cleanco' ),
	),
);
