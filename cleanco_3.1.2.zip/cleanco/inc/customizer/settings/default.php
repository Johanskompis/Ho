<?php
/**
 * This file config of WordPress default control for customizer.
 *
 * @package Cleanco
 */

$wp_customizer_controls['custom_logo'] = array(
	'section' => 'upload-logo',
);

$wp_customizer_controls['site_icon'] = array(
	'section' => 'address-icon',
);
