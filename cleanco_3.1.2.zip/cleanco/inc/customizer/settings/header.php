<?php
/**
 * This file config of custom control for customizer.
 *
 * @package Cleanco
 */

$cleanco_customizer_settings['header-styling'] = array(
	'section'     => 'header-styling',
	'type'        => 'radio',
	'default'     => 'layout-boxed',
	'label'       => esc_html__( 'Header Style', 'cleanco' ),
	'description' => esc_html__( 'This option affects your header layout. ( This control just temporary )', 'cleanco' ),
	'choices'     => array(
		'style-1' => esc_html__( 'Style 1', 'cleanco' ),
		'style-2' => esc_html__( 'Style 2', 'cleanco' ),
		'style-3' => esc_html__( 'Style 3', 'cleanco' ),
		'style-4' => esc_html__( 'Style 4', 'cleanco' ),
	),
);

$cleanco_customizer_settings['header_image_show_frontpage'] = array(
	'section'     => 'header_image',
	'type'        => 'custom',
	'custom_type' => 'cleanco-switcher',
	'default'     => 'cleanco-header-image-hide',
	'label'       => esc_html__( 'Display at Homepage', 'cleanco' ),
	'choices'     => array(
		'cleanco-header-image-show' => esc_html__( 'Show', 'cleanco' ),
		'cleanco-header-image-hide' => esc_html__( 'Hide', 'cleanco' ),
	),
);

$cleanco_customizer_settings['header_image_show_on_page'] = array(
	'section'     => 'header_image',
	'type'        => 'custom',
	'custom_type' => 'cleanco-switcher',
	'default'     => 'cleanco-header-image-show',
	'label'       => esc_html__( 'Display at Single Page', 'cleanco' ),
	'choices'     => array(
		'cleanco-header-image-show' => esc_html__( 'Show', 'cleanco' ),
		'cleanco-header-image-hide' => esc_html__( 'Hide', 'cleanco' ),
	),
);

$cleanco_customizer_settings['header_image_show_on_blog'] = array(
	'section'     => 'header_image',
	'type'        => 'custom',
	'custom_type' => 'cleanco-switcher',
	'default'     => 'cleanco-header-image-show',
	'label'       => esc_html__( 'Display at Blog', 'cleanco' ),
	'choices'     => array(
		'cleanco-header-image-show' => esc_html__( 'Show', 'cleanco' ),
		'cleanco-header-image-hide' => esc_html__( 'Hide', 'cleanco' ),
	),
);

$cleanco_customizer_settings['header_image_show_on_post'] = array(
	'section'     => 'header_image',
	'type'        => 'custom',
	'custom_type' => 'cleanco-switcher',
	'default'     => 'cleanco-header-image-show',
	'label'       => esc_html__( 'Display at Single Post', 'cleanco' ),
	'choices'     => array(
		'cleanco-header-image-show' => esc_html__( 'Show', 'cleanco' ),
		'cleanco-header-image-hide' => esc_html__( 'Hide', 'cleanco' ),
	),
);

if ( class_exists( 'WooCommerce' ) ) :
	$cleanco_customizer_settings['header_image_show_on_shop'] = array(
		'section'     => 'header_image',
		'type'        => 'custom',
		'custom_type' => 'cleanco-switcher',
		'default'     => 'cleanco-header-image-show',
		'label'       => esc_html__( 'Display at Shop', 'cleanco' ),
		'choices'     => array(
			'cleanco-header-image-show' => esc_html__( 'Show', 'cleanco' ),
			'cleanco-header-image-hide' => esc_html__( 'Hide', 'cleanco' ),
		),
	);

	$cleanco_customizer_settings['header_image_show_on_product'] = array(
		'section'     => 'header_image',
		'type'        => 'custom',
		'custom_type' => 'cleanco-switcher',
		'default'     => 'cleanco-header-image-hide-product',
		'label'       => esc_html__( 'Display at Single Product', 'cleanco' ),
		'choices'     => array(
			'cleanco-header-image-show-product' => esc_html__( 'Show', 'cleanco' ),
			'cleanco-header-image-hide-product' => esc_html__( 'Hide', 'cleanco' ),
		),
	);
endif;
