<?php
/**
 * This file config of custom control for customizer.
 *
 * @package Cleanco
 */

$cleanco_customizer_settings['logo-height'] = array(
	'section'     => 'upload-logo',
	'type'        => 'custom',
	'custom_type' => 'cleanco-input-slider',
	'default'     => 27,
	'unit'        => 'px',
	'priority'    => 9,
	'label'       => esc_html__( 'Height', 'cleanco' ),
	'description' => esc_html__( 'Recomended logo height is 21px.', 'cleanco' ),
	'transport'   => 'postMessage',
	'input_attrs' => array(
		'min'  => 10,
		'max'  => 250,
		'step' => 1,
	),
);

$cleanco_customizer_settings['logo-sticky'] = array(
	'section'   => 'upload-logo',
	'type'      => 'image',
	'priority'  => 9,
	'default'   => '',
	'label'     => esc_html__( 'Logo Sticky', 'cleanco' ),
	'transport' => 'refresh',
);

$cleanco_customizer_settings['logo-sticky-height'] = array(
	'section'     => 'upload-logo',
	'type'        => 'custom',
	'custom_type' => 'cleanco-input-slider',
	'default'     => 27,
	'unit'        => 'px',
	'priority'    => 9,
	'label'       => esc_html__( 'Logo Sticky Height', 'cleanco' ),
	'description' => esc_html__( 'Recomended logo height is 21px.', 'cleanco' ),
	'transport'   => 'postMessage',
	'input_attrs' => array(
		'min'  => 10,
		'max'  => 250,
		'step' => 1,
	),
);

$cleanco_customizer_settings['blog-type'] = array(
	'section'     => 'layout-option',
	'type'        => 'custom',
	'custom_type' => 'cleanco-switcher',
	'default'     => 'cleanco-blog-type-classic-blog',
	'label'       => esc_html__( 'Blog Type', 'cleanco' ),
	'transport'   => 'postMessage',
	'choices'     => array(
		'cleanco-blog-type-gutenberg-ready' => esc_html__( 'Gutenberg Ready', 'cleanco' ),
		'cleanco-blog-type-classic-blog'    => esc_html__( 'Classic Blog', 'cleanco' ),
	),
);

$cleanco_customizer_settings['blog-layout'] = array(
	'section'     => 'layout-option',
	'type'        => 'custom',
	'custom_type' => 'cleanco-switcher',
	'default'     => 'cleanco-layout-fullwidth',
	'label'       => esc_html__( 'Blog Layout', 'cleanco' ),
	'transport'   => 'postMessage',
	'choices'     => array(
		'cleanco-layout-fullwidth' => esc_html__( 'Fullwidth', 'cleanco' ),
		'cleanco-layout-boxed'     => esc_html__( 'Boxed', 'cleanco' ),
	),
);

$cleanco_customizer_settings['style-layout'] = array(
	'section'     => 'layout-option',
	'type'        => 'custom',
	'custom_type' => 'cleanco-switcher',
	'default'     => 'cleanco-classic-layout',
	'label'       => esc_html__( 'Layout Styles', 'cleanco' ),
	'transport'   => 'refresh',
	'choices'     => array(
		'cleanco-classic-layout' => esc_html__( 'Classic', 'cleanco' ),
		'cleanco-masonry-layout' => esc_html__( 'Masonry', 'cleanco' ),
	),
);

$cleanco_customizer_settings['sidebar-layout'] = array(
	'section'     => 'layout-option',
	'type'        => 'custom',
	'custom_type' => 'cleanco-image-selector',
	'default'     => 'sidebar-right',
	'transport'   => 'refresh',
	'label'       => esc_html__( 'Sidebar Option', 'cleanco' ),
	'description' => esc_html__( 'You can choose sidebar position on your site, is it in right, left, or no sidebar.', 'cleanco' ),
	'choices'     => array(
		'sidebar-right' => array(
			'image' => CLEANCO_THEME_URI . '/inc/customizer/assets/images/rs.png',
			'name'  => esc_html__( 'Right Sidebar', 'cleanco' ),
		),
		'sidebar-none'  => array(
			'image' => CLEANCO_THEME_URI . '/inc/customizer/assets/images/ns.png',
			'name'  => esc_html__( 'None Sidebar', 'cleanco' ),
		),
		'sidebar-left'  => array(
			'image' => CLEANCO_THEME_URI . '/inc/customizer/assets/images/ls.png',
			'name'  => esc_html__( 'Left Sidebar', 'cleanco' ),
		),
	),
);

$cleanco_customizer_settings['parallax-layout'] = array(
	'section'     => 'layout-option',
	'type'        => 'custom',
	'custom_type' => 'cleanco-switcher',
	'default'     => 'cleanco-header-parallax',
	'label'       => esc_html__( 'Header Image Scrolling', 'cleanco' ),
	'transport'   => 'refresh',
	'choices'     => array(
		'cleanco-header-parallax' => esc_html__( 'Parallax', 'cleanco' ),
		'cleanco-header-none'     => esc_html__( 'Static', 'cleanco' ),
	),
);

$cleanco_customizer_settings['dropdown-layout'] = array(
	'section'     => 'layout-option',
	'type'        => 'custom',
	'custom_type' => 'cleanco-switcher',
	'default'     => 'cleanco-dropdown-style',
	'label'       => esc_html__( 'Dropdown Style', 'cleanco' ),
	'transport'   => 'refresh',
	'choices'     => array(
		'cleanco-dropdown-style' => esc_html__( 'Selectize', 'cleanco' ),
		'cleanco-dropdown-none'  => esc_html__( 'Original', 'cleanco' ),
	),
);

$cleanco_customizer_settings['related-post-image'] = array(
	'section'     => 'layout-option',
	'type'        => 'custom',
	'custom_type' => 'cleanco-switcher',
	'label'       => esc_html__( 'Related Post Image', 'cleanco' ),
	'default'     => 'related-post-image-hidden',
	'choices'     => array(
		'related-post-image-hidden' => esc_html__( 'Hidden', 'cleanco' ),
		'related-post-image-show'   => esc_html__( 'Show', 'cleanco' ),
	),
);

$cleanco_customizer_settings['breadcrumbs-option'] = array(
	'section'     => 'layout-option',
	'type'        => 'custom',
	'custom_type' => 'cleanco-switcher',
	'label'       => esc_html__( 'Breadcrumbs', 'cleanco' ),
	'default'     => 'breadcrumbs-show',
	'choices'     => array(
		'breadcrumbs-hidden' => esc_html__( 'Hidden', 'cleanco' ),
		'breadcrumbs-show'   => esc_html__( 'Show', 'cleanco' ),
	),
);

$cleanco_customizer_settings['sticky-layout'] = array(
	'section'     => 'menu-option',
	'type'        => 'custom',
	'custom_type' => 'cleanco-switcher',
	'default'     => 'cleanco-sticky',
	'label'       => esc_html__( 'Navigation Position', 'cleanco' ),
	'transport'   => 'refresh',
	'choices'     => array(
		'cleanco-sticky' => esc_html__( 'Sticky', 'cleanco' ),
		'cleanco-scroll' => esc_html__( 'Scroll', 'cleanco' ),
	),
);

$cleanco_customizer_settings['navbar-font-color'] = array(
	'section'   => 'menu-option',
	'type'      => 'color',
	'default'   => '#333333',
	'transport' => 'refresh',
	'label'     => esc_html__( 'Font & Background Color', 'cleanco' ),
);

$cleanco_customizer_settings['navbar-background-color'] = array(
	'section'      => 'menu-option',
	'type'         => 'color-alpha',
	'default'      => '#ffffff',
	'capability'   => 'edit_theme_options',
	'transport'    => 'refresh',
	'show_opacity' => true,
	'palette'      => array(
		'rgb(150, 50, 220)',
		'rgba(50,50,50,0.8)',
		'rgba( 255, 255, 255, 0.2 )',
		'#00CC99',
	),
);

$cleanco_customizer_settings['navbar-font-sticky-color'] = array(
	'section'   => 'menu-option',
	'type'      => 'color',
	'default'   => '#333333',
	'transport' => 'refresh',
	'label'     => esc_html__( 'Font & Background Color Sticky', 'cleanco' ),
);

$cleanco_customizer_settings['navbar-background-sticky-color'] = array(
	'section'      => 'menu-option',
	'type'         => 'color-alpha',
	'default'      => '#ffffff',
	'capability'   => 'edit_theme_options',
	'transport'    => 'refresh',
	'show_opacity' => true,
	'palette'      => array(
		'rgb(150, 50, 220)',
		'rgba(50,50,50,0.8)',
		'rgba( 255, 255, 255, 0.2 )',
		'#00CC99',
	),
);

$cleanco_customizer_settings['navbar-bottom-border'] = array(
	'section'     => 'menu-option',
	'type'        => 'custom',
	'custom_type' => 'cleanco-switcher',
	'default'     => '1px solid #e3e3e3',
	'label'       => esc_html__( 'Bottom Border on Homepage', 'cleanco' ),
	'transport'   => 'refresh',
	'choices'     => array(
		'none'              => esc_html__( 'Hide', 'cleanco' ),
		'1px solid #e3e3e3' => esc_html__( 'Show', 'cleanco' ),
	),
);
