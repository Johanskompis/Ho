<?php
/**
 * This file config of custom control for customizer.
 *
 * @package Cleanco
 */

$cleanco_customizer_settings['primary-color'] = array(
	'section'     => 'colors',
	'type'        => 'color',
	'default'     => '#eeb70c',
	'transport'   => 'postMessage',
	'label'       => esc_html__( 'Brand Color', 'cleanco' ),
	'description' => esc_html__( 'Change your brand color', 'cleanco' ),
);
