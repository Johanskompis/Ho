<?php
/**
 * This file config of panels customizer.
 *
 * @package Cleanco
 */

$cleanco_customizer_panels['site-identity-panel'] = array(
	'title'       => esc_html__( 'Site Identities', 'cleanco' ),
	'description' => esc_html__( 'Control your blog setting\'s, layout, sidebar position', 'cleanco' ),
	'priority'    => 10,
);

$cleanco_customizer_panels['footer-panel'] = array(
	'title'       => esc_html__( 'Footer', 'cleanco' ),
	'description' => esc_html__( 'Control your footer setting\'s', 'cleanco' ),
	'priority'    => 110,
);
