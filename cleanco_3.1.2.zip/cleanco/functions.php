<?php
/**
 * Theme functions and definitions.
 *
 * Sets up the theme and provides some helper functions
 * For more information on hooks, actions, and filters,
 * see http://codex.wordpress.org/Plugin_API
 *
 * @package Cleanco
 */

// Core Constants.
define( 'CLEANCO_THEME_DIR', get_template_directory() );
define( 'CLEANCO_THEME_URI', get_template_directory_uri() );
// Minimum required PHP version.
define( 'CLEANCO_THEME_REQUIRED_PHP_VERSION', '5.2.4' );

/**
 * Set global content width
 *
 * @link https://developer.wordpress.com/themes/content-width/
 */
if ( ! isset( $content_width ) ) {
	$content_width = 900;
}

/**
 * Global variables
 */
$cleanco_customizer_panels   = array();
$cleanco_customizer_settings = array();
$cleanco_customizer_controls = array(
	'cleanco-image-selector'     => 'Cleanco_Image_Selector_Control',
	'cleanco-switcher'           => 'Cleanco_Switcher_Control',
	'cleanco-input-slider'       => 'Cleanco_Input_Slider_Control',
	'cleanco-alpha-color-picker' => 'Cleanco_Alpha_Color_Picker_Control',
	'cleanco-icon-picker'        => 'Cleanco_Icon_Picker_Control',
	'cleanco-link'               => 'Cleanco_Link_Control',
);

/**
 * Load all core theme function files.
 */
require get_parent_theme_file_path( '/inc/helpers.php' );
require get_parent_theme_file_path( '/inc/hooks.php' );
require get_parent_theme_file_path( '/inc/lib/class-cleanco-mobile-nav-walker.php' );
require get_parent_theme_file_path( '/inc/lib/webfonts.php' );
require get_parent_theme_file_path( '/inc/lib/class-tgm-plugin-activation.php' );
require get_parent_theme_file_path( '/inc/lib/class-cleanco-customizer-config.php' );
require get_parent_theme_file_path( '/inc/lib/class-cleanco-customizer-loader.php' );
require get_parent_theme_file_path( '/inc/lib/class-cleanco-walker-page.php' );

/**
 * Load panels, sections and settings.
 */
require get_parent_theme_file_path( '/inc/customizer/panels.php' );
require get_parent_theme_file_path( '/inc/customizer/sections.php' );
require get_parent_theme_file_path( '/inc/customizer/settings/general.php' );
require get_parent_theme_file_path( '/inc/customizer/settings/header.php' );
require get_parent_theme_file_path( '/inc/customizer/settings/colors.php' );
require get_parent_theme_file_path( '/inc/customizer/settings/footer.php' );
require get_parent_theme_file_path( '/inc/customizer/settings/default.php' );
require get_parent_theme_file_path( '/inc/customizer/settings/topbar.php' );

/**
 * Class instance init.
 */
$cleanco_customizer_loader = new Cleanco_Customizer_Loader();

add_action( 'tgmpa_register', 'cleanco_register_required_plugins' );

/**
 * Cleanco TGMPA
 */
function cleanco_register_required_plugins() {

	$plugins = array(
		array(
			'name'                  => esc_html__( 'Advanced Custom Fields','cleanco' ),
			'slug'                  => 'advanced-custom-fields',
			'required'              => true,
		),
		array(
			'name'                  => esc_html__( 'Contact Form 7','cleanco' ),
			'slug'                  => 'contact-form-7',
			'required'              => true,
		),
		array(
			'name'                  => esc_html__( 'WooCommerce','cleanco' ),
			'slug'                  => 'woocommerce',
			'required'              => false,
		),
		array(
			'name'                  => esc_html__( 'QuadMenu','cleanco' ),
			'slug'                  => 'quadmenu',
			'required'              => true,
		),
		array(
			'name'                  => esc_html__( 'Bookly','cleanco' ),
			'slug'                  => 'bookly-responsive-appointment-booking-tool',
			'required'              => true,
		),
		array(
			'name'                  => esc_html__( 'KingComposer','cleanco' ),
			'slug'                  => 'kingcomposer',
			'required'              => true,
		),
		array(
			'name'                  => esc_html__( 'Essential Grid','cleanco' ),
			'slug'                  => 'essential-grid',
			'required'              => true,
			'source'                => 'http://demoimporter.detheme.com/plugins/essential-grid.zip',
		),
		array(
			'name'                  => esc_html__( 'Slider Revolution','cleanco' ),
			'slug'                  => 'slider-revolution',
			'required'              => true,
			'source'                => 'http://demoimporter.detheme.com/plugins/slider-revolution.zip',
		),
		array(
			'name'                  => esc_html__( 'Footer Builder for Vast','cleanco' ),
			'slug'                  => 'vast-footer-builder',
			'required'              => true,
			'source'                => 'http://demoimporter.detheme.com/plugins/vast-footer-builder.zip',
		),
		array(
			'name'                  => esc_html__( 'Cleanco Plugin','cleanco' ),
			'slug'                  => 'cleanco-plugins',
			'required'              => true,
			'source'                => 'http://demoimporter.detheme.com/cleanco/plugins/cleanco-plugins.zip',
		),
		array(
			'name'                  => esc_html__( 'Vast Demo Import','cleanco' ),
			'slug'                  => 'vast-demo-import',
			'required'              => true,
			'source'                => 'http://demoimporter.detheme.com/cleanco/plugins/vast-demo-import.zip',
		),
		array(
			'name'                  => esc_html__( 'KC Pro!','cleanco' ),
			'slug'                  => 'kc_pro',
			'required'              => false,
			'source'                => 'http://demoimporter.detheme.com/plugins/kingcomposer_pro_plugin.zip',
		),
	);
	
	$config = array(
		'id'           => 'cleanco',                 // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '',                      // Default absolute path to bundled plugins.
		'menu'         => 'tgmpa-install-plugins', // Menu slug.
		'has_notices'  => true,                    // Show admin notices or not.
		'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => false,                   // Automatically activate plugins after installation or not.
		'message'      => '',                      // Message to output right before the plugins table.
	);

	tgmpa( $plugins, $config );

}
