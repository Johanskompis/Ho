<?php
/**
 * Displays post entry tags
 *
 * @package Cleanco
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<?php if ( has_tag() ) : ?>
<div class="entry__meta-tags">
	<?php
		$cleanco_tags = get_the_tags( get_the_ID() );
	if ( $cleanco_tags ) {
		foreach ( $cleanco_tags as $cleanco_tag ) {
			echo wp_kses( '<a href="' . esc_url( get_tag_link( $cleanco_tag->term_id ) ) . '" rel="tag" class="pills pills-default">' . $cleanco_tag->name . '</a>', 'post' );
		}
	}
	?>
</div>
<?php endif; ?>
