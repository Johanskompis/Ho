<?php
/**
 * Blog single tags
 *
 * @package Cleanco
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="uf-single-post__tags">

	<?php if ( has_tag() ) : ?>

		<?php
		$cleanco_tags = get_the_tags( get_the_ID() );
		foreach ( $cleanco_tags as $cleanco_tag ) {
			echo wp_kses( '<a href="' . esc_url( get_tag_link( $cleanco_tag->term_id ) ) . '" rel="tag" class="pills pills-default">' . $cleanco_tag->name . '</a>', 'post' );
		}
		?>

	<?php endif; ?>

</div>
